import 'dart:async';

import 'package:bookfin/catalog/model.dart';
import 'package:bookfin/playback/playback.dart';
import 'package:flutter_test/flutter_test.dart';

import 'playback_test.dart';

const otherFile = SourceFile(
  itemId: 'other',
  mediaSourceId: 'other-source',
  revision: 'r1',
  displayName: 'Other audio',
  durationMs: 60000,
  container: 'm4b',
  sizeBytes: 42,
);
const otherEdition = Edition(
  id: 'other-edition',
  kind: EditionKind.audio,
  label: 'Other narrator',
  files: [otherFile],
  memberIds: ['other:other-source'],
);
const otherBook = Book(
  id: 'other-book',
  title: 'Another journey',
  author: 'B. Writer',
  editions: [otherEdition],
);

class NoticeStore extends MemoryResume {
  bool recovered = false;
  bool failSave = false;
  @override
  bool setAside(String accountKey) => recovered;
  @override
  Future<void> save(String accountKey, ListeningChanges changes) async {
    if (failSave) throw Exception('storage full');
    await super.save(accountKey, changes);
  }
}

class NoticeEngine extends TestEngine {
  bool failLoad = false;
  bool failPlay = false;
  Completer<void>? failedPauseEntered;
  Completer<void>? releaseFailedPause;

  @override
  Future<void> load(List<Uri> sources, int fileIndex, int position) async {
    if (failLoad) throw Exception('decoder rejected file');
    await super.load(sources, fileIndex, position);
  }

  @override
  Future<void> play() async {
    if (failPlay) throw Exception('decoder rejected play');
    await super.play();
  }

  @override
  Future<void> pause() async {
    final release = releaseFailedPause;
    if (release != null) {
      releaseFailedPause = null;
      failedPauseEntered!.complete();
      await release.future;
      throw Exception('audio device failed while pausing');
    }
    await super.pause();
  }
}

void main() {
  late LocalFiles downloads;
  late NoticeStore store;
  late Playback playback;
  late NoticeEngine engine;
  setUp(() async {
    downloads = LocalFiles();
    store = NoticeStore();
    engine = NoticeEngine();
    playback = Playback(downloads: downloads, engine: engine, store: store);
    await playback.bind(account(), [title, otherBook]);
  });
  tearDown(() async {
    await playback.close();
    downloads.dispose();
  });

  test('playing the already-open edition clears a failed other-book action', () async {
    await playback.open(title, recording, autoplay: false);
    await playback.open(otherBook, otherEdition);
    expect(playback.message, contains('Download'));
    expect(playback.edition, recording);

    await playback.play();

    expect(playback.playing, isTrue);
    expect(playback.message, isNull);
    playback.checkInvariants();
  });

  test('opening an edition preserves unresolved record recovery', () async {
    await playback.bind(null, []);
    store.recovered = true;
    await playback.bind(account(), [title, otherBook]);
    expect(playback.message, contains('damaged'));

    await playback.open(title, recording);

    expect(playback.playing, isTrue);
    expect(playback.message, contains('damaged'));
  });

  test('a failed old-account read does not report on the replacement account', () async {
    await playback.bind(null, []);
    store.readGate = Completer<void>();
    store.failRead = true;
    final oldBinding = playback.bind(account(), [title, otherBook]);
    // Wait until the old read is held, then replace its account.
    await pumpEventQueue();
    final newBinding = playback.bind(null, []);
    store.readGate!.complete();
    await Future.wait([oldBinding, newBinding]);

    expect(playback.session, isNull);
    expect(playback.message, isNull);
  });

  test('a failed load belongs to the attempted edition, not the retained player', () async {
    await playback.open(title, recording, autoplay: false);
    downloads.files[otherFile.key] = Uri.file('/other.m4b');
    engine.failLoad = true;
    await playback.open(otherBook, otherEdition);

    expect(playback.edition, recording);
    expect(playback.statusNotifier.value.messagesFor(edition: recording), isEmpty);
    expect(playback.statusNotifier.value.messagesFor(book: otherBook), contains(contains('Cannot play')));
    expect(playback.statusNotifier.value.actionNotice?.operation, PlaybackOperation.open);
    engine.failLoad = false;
    await playback.play();
    expect(playback.playing, isTrue);
    expect(playback.statusNotifier.value.actionNotice, isNull);
  });

  test('a failed Play remains visible for its edition until Play succeeds', () async {
    await playback.open(title, recording, autoplay: false);
    engine.failPlay = true;
    await playback.play();
    expect(playback.statusNotifier.value.messagesFor(edition: recording), contains(contains('Cannot play')));
    expect(playback.statusNotifier.value.actionNotice?.operation, PlaybackOperation.play);
    await playback.flush();
    expect(playback.statusNotifier.value.actionNotice, isNotNull);
    engine.failPlay = false;
    await playback.play();
    expect(playback.statusNotifier.value.actionNotice, isNull);
    expect(playback.playing, isTrue);
  });

  test('a late error while pausing a failed action cannot reach a new account', () async {
    await playback.open(title, recording, autoplay: false);
    engine.failPlay = true;
    engine.failedPauseEntered = Completer<void>();
    final release = engine.releaseFailedPause = Completer<void>();
    final failed = playback.play();
    await engine.failedPauseEntered!.future;
    final replacement = playback.bind(account(user: 'bob'), [title, otherBook]);
    release.complete();
    await Future.wait([failed, replacement]);

    expect(playback.session!.scope.userId, 'bob');
    expect(playback.statusNotifier.value.messagesFor(book: title), isEmpty);
    expect(playback.edition, isNull);
    playback.checkInvariants();
  });

  test('save retry resolves only the save notice and keeps recovery and action notices', () async {
    await playback.bind(null, []);
    store.recovered = true;
    await playback.bind(account(), [title, otherBook]);
    store.failSave = true;
    await playback.open(title, recording, autoplay: false);
    await playback.addBookmark(title: 'Keep this');
    await playback.open(otherBook, otherEdition);
    final status = playback.statusNotifier.value;
    expect(status.messagesFor(book: otherBook), hasLength(3));
    expect(status.saveFailed, isTrue);

    store.failSave = false;
    await playback.flush();

    expect(playback.statusNotifier.value.saveFailed, isFalse);
    expect(playback.statusNotifier.value.actionNotice, status.actionNotice);
    expect(playback.statusNotifier.value.recoveryMessage, status.recoveryMessage);
    expect(playback.bookmarks.single.title, 'Keep this');
    await playback.play();
    expect(playback.statusNotifier.value.actionNotice, isNull);
    expect(playback.statusNotifier.value.messagesFor(), contains(contains('damaged')));
    playback.checkInvariants();
  });

  test('a failed automatic reopen is an edition action error, not record recovery', () async {
    await playback.open(title, recording, autoplay: false);
    await playback.bind(null, []);
    engine.failLoad = true;
    await playback.bind(account(), [title, otherBook]);

    expect(playback.statusNotifier.value.messagesFor(), isEmpty);
    expect(playback.statusNotifier.value.messagesFor(book: title), contains(contains('Cannot play')));
    expect(playback.statusNotifier.value.actionNotice?.operation, PlaybackOperation.open);
  });
}
