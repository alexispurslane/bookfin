// Temporary controlled diagnostic; retained as compressed evidence, not shipped.
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:bookfin/reader/epub/publication.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';

import '../../../tool/showcase_media.dart' as media;
import '../publication_test.dart' as shared;
import 'admission_test.dart' as admission;
import 'corpus/book.dart' as corpus;
import 'damaged_chapters_test.dart' as damaged;
import 'epubjs_fixtures.dart' as recorded;
import 'page_source_test.dart' as pages;
import 'section_styles_test.dart' as styles;

T at<T>(int second, T Function() build) => runZoned(
  build,
  zoneValues: {#teC2tcArchiveTime: DateTime(2026, 1, 1, 12, 0, second)},
);

Map<String, Object> observe(Uint8List bytes) => {
  'digest': sha256.convert(bytes).toString(),
  'entries': [
    for (final file in ZipDecoder().decodeBytes(bytes).files)
      {'name': file.name, 'payload': sha256.convert(file.content).toString()},
  ],
};

void archiveChecks(String name, Uint8List Function(bool changed) build) {
  test('$name keeps identical archive bytes across encode times', () {
    final first = at(0, () => build(false));
    final later = at(2, () => build(false));
    final a = observe(first);
    final b = observe(later);
    print('OBSERVATION ${jsonEncode({'builder': name, 'first': a, 'later': b})}');
    expect(a['entries'], b['entries'], reason: 'entry payloads and order');
    expect(later, orderedEquals(first), reason: 'encode time is not content');
  });
  test('$name keeps a different identity for changed content', () {
    final first = at(0, () => build(false));
    final changed = at(0, () => build(true));
    expect(observe(changed)['entries'], isNot(observe(first)['entries']));
    expect(sha256.convert(changed), isNot(sha256.convert(first)));
    expect(Publication.admit(changed).identity,
        isNot(Publication.admit(first).identity));
  });
}

void main() {
  test('control changes the default clock without changing entry contents', () {
    Uint8List build() => ZipEncoder().encodeBytes(
      Archive()..add(ArchiveFile.string('chapter.xhtml', '<p>River</p>')),
    );
    final first = at(0, build);
    final later = at(2, build);
    expect(observe(first)['entries'], observe(later)['entries']);
    expect(first, isNot(orderedEquals(later)));
  });
  archiveChecks('admission.archive', (changed) => admission.withNav(
    '<nav epub:type="toc"><ol><li><a href="text/one.xhtml#a">'
    '${changed ? 'Changed' : 'River'}</a></li></ol></nav>',
  ));
  archiveChecks('epubjs.asRecorded', (changed) => recorded.asRecorded(
    shared.epub(extra: {'OPS/book.css': utf8.encode(
      'p { color: ${changed ? 'red' : 'black'}; }',
    )}),
  ));
  archiveChecks('corpus.madeUpEpub', (changed) => corpus.madeUpEpub(
    ['<p>${changed ? 'Changed' : 'River'}</p>'],
    css: 'p { font-size: 18px; }',
  ));
  archiveChecks('showcase.epub', (changed) => media.epub(
    'river', 'River', 'Author',
    [('One', [changed ? 'Changed' : 'River', 'Bank'])],
    endnotes: ['A note'], footnotes: ['A footnote'],
  ));
  archiveChecks('damaged._book', (changed) => damaged.diagnosticBook(changed));
  archiveChecks('styles.styledBook', (changed) => styles.styledBook(
    unused: 0, extraSheets: {'one.css': 'p { color: ${changed ? 'red' : 'black'}; }'},
  ));
  test('pages.book keeps its identity across encode times', () {
    final first = at(0, () => pages.book(['<p>River</p>']));
    final later = at(2, () => pages.book(['<p>River</p>']));
    Map<String, Object> observation(Publication book) => {
      'digest': book.originalDigest,
      'entries': [for (final entry in book.textFiles.entries)
        {'name': entry.key, 'payload': sha256.convert(entry.value).toString()}],
    };
    print('OBSERVATION ${jsonEncode({'builder': 'pages.book',
      'first': observation(first), 'later': observation(later)})}');
    expect(later.textFiles, first.textFiles);
    expect(later.originalDigest, first.originalDigest);
    expect(later.identity, first.identity);
  });
  test('pages.book keeps a different identity for changed content', () {
    final first = at(0, () => pages.book(['<p>River</p>']));
    final changed = at(0, () => pages.book(['<p>Changed</p>']));
    expect(changed.textFiles, isNot(first.textFiles));
    expect(changed.originalDigest, isNot(first.originalDigest));
    expect(changed.identity, isNot(first.identity));
  });
}
