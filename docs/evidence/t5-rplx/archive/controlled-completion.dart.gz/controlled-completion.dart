// A failed read of an account's reading records must not cost the places
// that the user reads afterwards (boo-y2sj, engine rule 3). The session
// keeps those changes, reads the records again, and saves the changes when
// the records open. It never saves before the read: a save carries the
// whole settings, so a save from unread records would replace the saved
// text size with the default.
import 'dart:async';

import 'package:bookfin/playback/store.dart';
import 'package:bookfin/reader/epub/publication.dart';
import 'package:bookfin/reader/session.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../playback/playback_test.dart' show account, LocalFiles;
import 'publication_test.dart' show epub;
import 'session_test.dart' show source, edition, book, visible;

/// Reading records whose read fails until [readable].
class UnreadableRecords extends ReadingStore {
  UnreadableRecords(this.records);
  final ReadingRecords records;
  bool readable = false;
  final saveStarted = Completer<void>();
  final saveCompleted = Completer<void>();
  Completer<void>? allowSave;
  final trace = <String>[];
  @override
  Future<Map<String, dynamic>?> read(String key) async {
    if (!readable) {
      trace.add('read rejected');
      throw Exception('Storage is unavailable');
    }
    trace.add('retry read started');
    final value = await records.read(key);
    trace.add('retry read completed');
    return value;
  }

  @override
  Future<void> saveReading(String key, ReadingChanges changes) async {
    trace.add('save started');
    if (!saveStarted.isCompleted) saveStarted.complete();
    await allowSave?.future;
    await records.saveReading(key, changes);
    trace.add('real save completed');
    if (!saveCompleted.isCompleted) saveCompleted.complete();
  }
  @override
  void acceptSnapshot(String key, Map<String, dynamic>? value) =>
      records.acceptSnapshot(key, value);
}

void main() {
  late LocalFiles downloads;
  late Publication publication;
  late UnreadableRecords storage;
  late ReaderSession reader;
  final key = account().scope.key;

  /// The reading records as a new process reads them.
  Future<Map<String, dynamic>?> saved() => LocalResumeStore().reading.read(key);

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    downloads = LocalFiles()..files[source.key] = Uri.file('/verified.epub');
    publication = Publication.admit(epub());
    // An earlier run saved a text size of 22.
    final earlier = ReaderSession(
      downloads: downloads,
      store: LocalResumeStore().reading,
      load: (_) async => publication,
    );
    await earlier.bind(account(), [book]);
    await earlier.setFontSize(22);
    earlier.dispose();
    await earlier.flush();
    expect((await saved())!['fontSize'], 22);

    storage = UnreadableRecords(LocalResumeStore().reading);
    reader = ReaderSession(
      downloads: downloads,
      store: storage,
      load: (_) async => publication,
    );
    await reader.bind(account(), [book]);
    await reader.open(book, edition);
  });
  tearDown(() async {
    reader.dispose();
    await reader.flush();
    downloads.dispose();
  });

  test('a place read while the records could not be opened is saved when '
      'they open', () async {
    expect(reader.message, contains('could not be opened'));
    reader.acceptVisible(reader.token, visible);

    storage.readable = true;
    await reader.flush();

    expect(
      ((await saved())!['resumes'] as List).map((place) => place['anchor']),
      [contains(visible.cfi)],
    );
  });

  test('the next place after a failed read opens the records again without '
      'a flush', () async {
    final allowSave = storage.allowSave = Completer<void>();
    storage.readable = true;
    storage.trace.add('storage readable; accept next visible place');
    reader.acceptVisible(reader.token, visible);
    await storage.saveStarted.future;
    await pumpEventQueue();
    storage.trace.add('pumpEventQueue completed while save held');
    final before = (await saved())!;
    storage.trace.add('fresh read before release: ${before['resumes']}');
    allowSave.complete();
    storage.trace.add('save released');
    await storage.saveCompleted.future;
    final after = (await saved())!;
    storage.trace.add('fresh read after completion: ${after['resumes']}');
    print(storage.trace.join('\n'));
    expect(after['resumes'], hasLength(1));
    expect(after['fontSize'], 22);
    expect(before['resumes'], isEmpty);
    expect(reader.fontSize, 22);
  });

  test('the saved text size survives places read while the records could '
      'not be opened', () async {
    reader.acceptVisible(reader.token, visible);
    storage.readable = true;
    await reader.flush();

    expect((await saved())!['fontSize'], 22);
    expect(reader.fontSize, 22);
  });

  test('no place is saved while the records stay unread', () async {
    reader.acceptVisible(reader.token, visible);
    await reader.flush();

    expect((await saved())!['resumes'], isEmpty);
    expect((await saved())!['fontSize'], 22);
  });

  test('the notice about unread records ends when the records open',
      () async {
    reader.acceptVisible(reader.token, visible);
    storage.readable = true;
    await reader.flush();

    expect(reader.message, isNull);
    expect(reader.canBookmark, isTrue);
  });
}
