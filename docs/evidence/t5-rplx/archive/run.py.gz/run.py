import datetime, hashlib, json, pathlib, shlex, subprocess, sys, time
root = pathlib.Path('/tmp/t5-rplx-logs')
name, *command = sys.argv[1:]
log = root / (name + '.log')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
with log.open('w') as out:
    run = subprocess.run(command, stdout=out, stderr=subprocess.STDOUT)
record = dict(name=name, command=shlex.join(command), cwd=str(pathlib.Path.cwd()), started=started, seconds=round(time.monotonic()-tick, 3), exitCode=run.returncode, log=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest(), bytes=log.stat().st_size)
with (root / 'commands.jsonl').open('a') as out:
    out.write(json.dumps(record) + '\n')
print(json.dumps(record))
print('\n'.join(log.read_text(errors='replace').splitlines()[-8:]))
sys.exit(run.returncode)
